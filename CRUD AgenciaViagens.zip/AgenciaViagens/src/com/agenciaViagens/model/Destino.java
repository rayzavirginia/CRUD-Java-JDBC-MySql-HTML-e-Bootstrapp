package com.agenciaViagens.model;

public class Destino {

	public class Cliente {
		private int idDestino;
		private String nomeDestino;
		private String estadoDestino;
		private String paisDestino;
		private String dataDestino;
		private String precoDestino;
		
		
		public Cliente(int idDestino, String nomeDestino, String estadoDestino, String paisDestino, String dataDestino,
				String precoDestino) {
			super();
			this.idDestino = idDestino;
			this.nomeDestino = nomeDestino;
			this.estadoDestino = estadoDestino;
			this.paisDestino = paisDestino;
			this.dataDestino = dataDestino;
			this.precoDestino = precoDestino;
		}


		public int getIdDestino() {
			return idDestino;
		}


		public void setIdDestino(int idDestino) {
			this.idDestino = idDestino;
		}


		public String getNomeDestino() {
			return nomeDestino;
		}


		public void setNomeDestino(String nomeDestino) {
			this.nomeDestino = nomeDestino;
		}


		public String getEstadoDestino() {
			return estadoDestino;
		}


		public void setEstadoDestino(String estadoDestino) {
			this.estadoDestino = estadoDestino;
		}


		public String getPaisDestino() {
			return paisDestino;
		}


		public void setPaisDestino(String paisDestino) {
			this.paisDestino = paisDestino;
		}


		public String getDataDestino() {
			return dataDestino;
		}


		public void setDataDestino(String dataDestino) {
			this.dataDestino = dataDestino;
		}


		public String getPrecoDestino() {
			return precoDestino;
		}


		public void setPrecoDestino(String precoDestino) {
			this.precoDestino = precoDestino;
		}
		
		
		
		
	}

	public void setNomeDestino(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setEstadoDestino(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setPaisDestino(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setDataDestino(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setPrecoDestino(String string) {
		// TODO Auto-generated method stub
		
	}

	

	public String getEstadoDestino() {
	
		return getEstadoDestino();
	}

	public String getPaisDestino() {
		// TODO Auto-generated method stub
		return getPaisDestino();
	}

	public String getDataDestino() {
		// TODO Auto-generated method stub
		return getDataDestino();
	}

	public String getPrecoDestino() {
		// TODO Auto-generated method stub
		return getPrecoDestino();
	}

	public void setIdDestino(int int1) {
		// TODO Auto-generated method stub
		
	}

	public int getIdDestino() {
		// TODO Auto-generated method stub
		return getIdDestino();
	}

	public String getNomeDestino() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
