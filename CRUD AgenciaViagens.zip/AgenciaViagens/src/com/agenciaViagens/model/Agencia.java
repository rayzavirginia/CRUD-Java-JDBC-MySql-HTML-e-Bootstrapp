package com.agenciaViagens.model;

public class Agencia {

	public class Cliente {
		private int idAgencia;
		private String nomeAgencia;
		private String cnpjAgencia;
		private String siteAgencia;
		private String enderecoAgencia;
		
		
		public Cliente(int idAgencia, String nomeAgencia, String cnpjAgencia, String siteAgencia,
				String enderecoAgencia) {
			super();
			this.idAgencia = idAgencia;
			this.nomeAgencia = nomeAgencia;
			this.cnpjAgencia = cnpjAgencia;
			this.siteAgencia = siteAgencia;
			this.enderecoAgencia = enderecoAgencia;
		}


		public int getIdAgencia() {
			return idAgencia;
		}


		public void setIdAgencia(int idAgencia) {
			this.idAgencia = idAgencia;
		}


		public String getNomeAgencia() {
			return nomeAgencia;
		}


		public void setNomeAgencia(String nomeAgencia) {
			this.nomeAgencia = nomeAgencia;
		}


		public String getCnpjAgencia() {
			return cnpjAgencia;
		}


		public void setCnpjAgencia(String cnpjAgencia) {
			this.cnpjAgencia = cnpjAgencia;
		}


		public String getSiteAgencia() {
			return siteAgencia;
		}


		public void setSiteAgencia(String siteAgencia) {
			this.siteAgencia = siteAgencia;
		}


		public String getEnderecoAgencia() {
			return enderecoAgencia;
		}


		public void setEnderecoAgencia(String enderecoAgencia) {
			this.enderecoAgencia = enderecoAgencia;
		}
		
		
	}

	public Agencia(int i, String sql, String sql2, String sql3, String sql4) {
		// TODO Auto-generated constructor stub
	}

	public Agencia() {
		// TODO Auto-generated constructor stub
	}

	public String getNomeAgencia() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setIdAgencia(int int1) {
		// TODO Auto-generated method stub
		
	}

	public void setNomeAgencia(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setCnpjAgencia(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setSiteAgencia(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setEnderecoAgencia(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getCnpjAgencia() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getSiteAgencia() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getEnderecoAgencia() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getIdAgencia() {
		// TODO Auto-generated method stub
		return 0;
	}
}
