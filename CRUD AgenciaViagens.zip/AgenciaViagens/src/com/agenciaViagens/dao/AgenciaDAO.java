package com.agenciaViagens.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.agenciaViagens.database.DatabaseConnection;
import com.agenciaViagens.model.Agencia;


public class AgenciaDAO {

	/*
	 * CRUD
	 * C: CREATE
	 * R: READ
	 * U: UPDATE
	 * D: DELETE
	 */
	
//----------------------------------CREATE----------------------------------------------------

	public static void save(Agencia agencia) {
		String sql = "INSERT INTO agencia_de_viagens (nomeAgencia, cnpjAgencia, siteAgencia, enderecoAgencia) "
				+ "VALUES (?, ?, ?, ?)";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//criar uma conexão com o banco de dados
			conn = DatabaseConnection.createConnectionToMySQL();
			
			//criamos uma PreparedStatement para executar uma query
			pstm = conn.prepareStatement(sql);
			//adicionar os valores que são esperados pela query
			pstm.setString(1, agencia.getNomeAgencia());
			pstm.setString(2, agencia.getNomeAgencia());
			pstm.setString(3, agencia.getNomeAgencia());
			pstm.setString(4, agencia.getNomeAgencia());
			
			//executar a query
			pstm.execute();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			
			//Fechar as conexões
			try {
				if (pstm!= null) {
					pstm.close();
				}
				
				if(conn!= null ) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}

	}


	
	
//------------------------------------READ---------------------------------------------------	
	
		public List<Agencia> getAgencia() {
		String sql = "SELECT * FROM agencia_de_viagens";
		
		List<Agencia> Agencia = new ArrayList<Agencia>();
	
		Connection conn = null;
		PreparedStatement pstm = null;
		
		//classe que vai recuperar os dados do banco ***SELECT***
		ResultSet rset = null;
		
		try {
			conn = DatabaseConnection.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			rset = pstm.executeQuery();
			
			while (rset.next()) {
				Agencia agencia = new Agencia();
				
				//recuperar o Id
				agencia.setIdAgencia(rset.getInt("idAgencia"));
				//recuperar o nome
				agencia.setNomeAgencia(rset.getString("nomeAgencia"));
				//recuperar cpf
				agencia.setCnpjAgencia(rset.getString("cnpjAgencia"));
				//recuperar endereço
				agencia.setSiteAgencia(rset.getString("siteAgencia"));
				//recuperar telefone
				agencia.setEnderecoAgencia(rset.getString("enderecoAgencia"));
				
				Agencia.add(agencia);
				}
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(rset!=null) {
						rset.close();
					}
					
					if(pstm!=null) {
						pstm.close();
					}
					
					if(conn!=null) {
						conn.close();
					}
				}catch(Exception e) {
				e.printStackTrace();
			    }
			}
		return Agencia;
	}
		 
	

//-----------------------------------UPDATE-----------------------------------------------	
	
	
	public void update(Agencia agencia) {
		String sql = "UPDATE agencia_de_viagens SET nomeAgencia = ?, cnpjAgencia = ?, siteAgencia = ?, enderecoAgencia = ? WHERE idAgencia = ?";
		
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			//criar conexão
			conn = DatabaseConnection.createConnectionToMySQL();
			
			//classe para executar a query
			pstm = conn.prepareStatement(sql);
			
			//adicionar os valores para atualizar
			pstm.setString(1, agencia.getNomeAgencia());
			pstm.setString(2, agencia.getCnpjAgencia());
			pstm.setString(3, agencia.getSiteAgencia());
			pstm.setString(4, agencia.getEnderecoAgencia());
			
			//Qual o id do registro que deseja atualizar
			pstm.setInt(5, agencia.getIdAgencia());
			
			//Executar a Query
			pstm.execute();
	        }catch (Exception e) {
		      e.printStackTrace();
	        }finally {
		      try {
		         if(pstm!=null) {
			         pstm.close();
		      }
		
		         if(conn!=null) {
			         conn.close();
		      }
	          
		      }catch (Exception e) {
		         e.printStackTrace();
	          }

             }
        }
   
	
	
//-----------------------------------DELETE-----------------------------------------------


	public static void deleteByIdCliente(int idCliente) {
		String sql = "DELETE FROM agencia_de_viagens WHERE idAgencia = ?";
		
		Connection conn = null;
		
		PreparedStatement pstm = null;
		
		try {
			conn = DatabaseConnection.createConnectionToMySQL();
			
			pstm = conn.prepareStatement(sql);
			
			int idAgencia = 0;
			pstm.setInt(1, idAgencia);
			
			pstm.execute();
			}catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(pstm!=null) {
						pstm.close();
					}
					
					if(conn!=null) {
						conn.close();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
		   }
	  }




	public static void deleteByIdAgencia(int i) {
		// TODO Auto-generated method stub
		
	}
	
}
