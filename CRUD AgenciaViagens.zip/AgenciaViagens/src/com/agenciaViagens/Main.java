package com.agenciaViagens;

import com.agenciaViagens.dao.ClienteDAO;
import com.agenciaViagens.model.Cliente;

public class Main {

	public static void main(String[] args) {
		
		ClienteDAO clienteDAO = new ClienteDAO();
		
//-------------------CADASTRAR CLIENTE----------------------------
		
	 /*   Cliente cliente = new Cliente();
		cliente.setNomeCliente("Maria Vitoria");
		cliente.setCpfCliente("888888-888");
		cliente.setEnderecoCliente("Rua 15 Teresina/PI");
		cliente.setTelefoneCliente("8888-8888");
		
		//clienteDAO.save(cliente);
		 */
	
//------- ----VIZUALIZAÇÃO DOS CLIENTES CADASTRADOS---------------
		
		for(Cliente c : clienteDAO.getClientes()) {
			System.out.print("Cliente: " +c.getNomeCliente() + " /CPF: " +c.getCpfCliente() +
				" /Endereço: " + c.getEnderecoCliente() + " /Telefone: " + c.getTelefoneCliente());
		}
		
		 
		
		
//-------------------ATUALIZAR CLIENTE----------------------------
		
	/*	Cliente c1 = new Cliente();
		c1.setNomeCliente("Maria Vitoria da Silva");
		c1.setCpfCliente("9999999-99");
		c1.setEnderecoCliente("Rua 18, Fortaleza/CE");
		c1.setTelefoneCliente("7777-7777");
		c1.setIdCliente(2); */
		
		//clienteDAO.update(c1);
		
		
//-----------DELETAR CLIENTE PELO NÚMERO DO ID--------------------
		
		ClienteDAO.deleteByIdCliente(1);
	}
}
