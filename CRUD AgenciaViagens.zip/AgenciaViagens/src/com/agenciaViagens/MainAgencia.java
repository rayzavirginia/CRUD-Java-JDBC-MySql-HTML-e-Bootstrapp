package com.agenciaViagens;

import com.agenciaViagens.dao.AgenciaDAO;
import com.agenciaViagens.model.Agencia;

public class MainAgencia {

public static void main(String[] args) {
		
		AgenciaDAO agenciaDAO = new AgenciaDAO();
		
//-------------------CADASTRAR AGÊNCIA----------------------------
		
	/*    Agencia agencia = new Agencia();
		agencia.setNomeAgencia("Viagens Tour");
		agencia.setCnpjAgencia("555555.00001-00");
		agencia.setSiteAgencia("Rua 10 Teresina/PI");
		agencia.setEnderecoAgencia("8888-9999");
		
		AgenciaDAO.save(agencia);  */
		 
	
//------- ----VIZUALIZAÇÃO DAS AGÊNCIAS CADASTRADAS----------------
		
	/*	for(Agencia a : agenciaDAO.getAgencia()) {
			System.out.print("Agência: " +a.getNomeAgencia() + " /CNPJ: " +a.getCnpjAgencia() +
				" /Site: " + a.getSiteAgencia() + " /Endereço: " + a.getEnderecoAgencia());
		}  */
		
		 
		
		
//-------------------ATUALIZAR AGÊNCIA----------------------------
		
	/*	Agencia a1 = new Agencia(0, null, null, null, null);
		a1.setNomeAgencia("Viagem Tour");
		a1.setCnpjAgencia("9999999.999.0001-00");
		a1.setSiteAgencia("www.viagemtour.com");
		a1.setEnderecoAgencia("4444-4444");
		a1.setIdAgencia(1);
		
		
		agenciaDAO.update(a1);  */
		
		
//-----------DELETAR AGÊNCIA PELO NÚMERO DO ID--------------------
		
	  AgenciaDAO.deleteByIdAgencia(1);
	}
}
	

